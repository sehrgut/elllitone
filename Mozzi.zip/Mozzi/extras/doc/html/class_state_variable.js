var class_state_variable =
[
    [ "StateVariable", "class_state_variable.html#a9950b71a16f63654552d3e15774d6638", null ],
    [ "next", "class_state_variable.html#a14cb100c22e4a33025665ef3620ca2b8", null ],
    [ "setCentreFreq", "class_state_variable.html#a47e7ddad76db7009e370fa91ea5d4d3d", null ],
    [ "setResonance", "class_state_variable.html#a992e23a80b611b72e3e764c14d5ee188", null ]
];