var class_over_sample =
[
    [ "add", "class_over_sample.html#a9c9f4083b726ed046c97a91535486317", null ],
    [ "next", "class_over_sample.html#a7f447746d8296314b4ad5184b0654646", null ]
];