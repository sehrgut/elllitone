var class_wave_shaper_3_01char_01_4 =
[
    [ "WaveShaper", "class_wave_shaper_3_01char_01_4.html#a6364609248c42174f9f7e4974585e301", null ],
    [ "next", "class_wave_shaper_3_01char_01_4.html#a8aa75261350b2651a2cbca264a02e944", null ]
];