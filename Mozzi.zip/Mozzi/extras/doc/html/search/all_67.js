var searchData=
[
  ['getaudioinput',['getAudioInput',['../group__analog.html#ga3f15eb8d6694020d170ebcbedb645de7',1,'getAudioInput():&#160;MozziGuts.cpp'],['../group__analog.html#ga3f15eb8d6694020d170ebcbedb645de7',1,'getAudioInput():&#160;MozziGuts.cpp']]],
  ['getmax',['getMax',['../class_auto_range.html#a4d27e5fe43f9b376b537def88ac74119',1,'AutoRange']]],
  ['getmean',['getMean',['../class_rolling_stat.html#aed85e98ab32f0a731dc12f9f1c4da398',1,'RollingStat']]],
  ['getmin',['getMin',['../class_auto_range.html#acd1dae6e6ffb288efc1618e2453ad5ef',1,'AutoRange']]],
  ['getphasefractional',['getPhaseFractional',['../class_oscil.html#aa774ef68b06f9652e6ac23d4e9332554',1,'Oscil']]],
  ['getrange',['getRange',['../class_auto_range.html#a75c842b27ad3917be6d29e3d35b485f3',1,'AutoRange']]],
  ['getstandarddeviation',['getStandardDeviation',['../class_rolling_stat.html#ade29f8eea338da4879fa692ea2b28bc3',1,'RollingStat']]],
  ['getvariance',['getVariance',['../class_rolling_stat.html#a9d145736669d070194b8149eec084bc0',1,'RollingStat']]]
];
