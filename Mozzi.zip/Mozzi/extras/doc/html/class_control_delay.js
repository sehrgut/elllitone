var class_control_delay =
[
    [ "next", "class_control_delay.html#a19258636609d83a2bab11849e17b5294", null ],
    [ "next", "class_control_delay.html#a41c09b5cc9e817d8eaf111b0f74c9a0b", null ],
    [ "read", "class_control_delay.html#a26b409fbfc322ae527ba23680c56e3a9", null ],
    [ "set", "class_control_delay.html#a7bd0a07f7803afda1a71b50e3f66827b", null ]
];